/*
 * main.c


 *
 *  Created on: 26/02/2021
 *      Author: arantxa
 */

#include "../include/leon3_ev_handling.h"
#include "../include/leon3_hw_irqs.h"

#include "../include/leon3_uart.h"
#include "../include/leon3_bprint.h"

#include "../include/leon3_monotonic_clk.h"
#include "../include/leon3_timer_unit_drv.h"
#include "../include/leon3_timing_service_config.h"
#include "../include/leon3_ttre.h"

void ROBOTAvoidObstacles(void) {

	leon3_print_string("\n Avoid Obstacles");

}

void ROBOTAdvanceInPath(void) {

	leon3_print_string("\nAdvance");

}

void ROBOTCalculatePath(void){

	leon3_print_string("\nCalculate Path ");

}

//10 Ticks per second
#define TICKS_PER_SECOND 10

int main() {

	uint32_t aux1, aux2;

	//Install handlers for enable and disable irqs
	leon3_install_handler(LEON3_SPARC_ENABLE_IRQ_TRAPVECTOR, leon3_trap_handler_enable_irqs);
	leon3_install_handler(LEON3_SPARC_DISABLE_IRQ_TRAPVECTOR, leon3_trap_handler_disable_irqs);

	//Init Monotonic Clock
	InitMonotonicClock(date_time_to_Y2K(1, 1, 13, 0, 0, 1));

	TTRE_InitService(TICKS_PER_SECOND);
	TTRE_ProgramRoutine(ROBOTAvoidObstacles, 00000);
	TTRE_ProgramRoutine(ROBOTCalculatePath, 100000);
	TTRE_ProgramRoutine(ROBOTAvoidObstacles, 200000);
	TTRE_ProgramRoutine(ROBOTAdvanceInPath, 300000);
	TTRE_ProgramRoutineEveryTick(UpdateMonotonicClock);

	//Init Timing Service
	InitTimingService(TICKS_PER_SECOND, IRQHandlerExecuteProgrammedRoutines);

	aux2=0;

	while(1) {
		aux1 = GetUniversalTime_Y2K();
		//Cada segundo mostramos el tiempo
		if (aux1!=aux2){
			leon3_mask_irq(8); //Inicio sección crítica
			print_date_time_from_Y2K(aux1);
			aux2=aux1;
			leon3_unmask_irq(8); // Fin sección crítica
		}
	}
	return 0;
}
